// The New Roots Project — interactive volunteer globe (needs d3 + topojson loaded first)
(function () {
  var canvas = document.getElementById('globe');
  if (!canvas || !window.d3 || !window.topojson) return;

  // To add a location: {l:"Label", lat: latitude, lng: longitude}
  var vols = [
    {l:"India",lat:20.59,lng:78.96},{l:"London, UK",lat:51.51,lng:-.13},{l:"Telford, England",lat:52.68,lng:-2.45},{l:"United Kingdom",lat:53.48,lng:-2.24},{l:"United Kingdom",lat:55.86,lng:-4.25},{l:"Mongolia",lat:47.9,lng:106.91},{l:"Australia",lat:-33.87,lng:151.21},{l:"Calgary, Canada",lat:51.04,lng:-114.07},{l:"Canada",lat:53.54,lng:-113.49},{l:"Canada",lat:49.25,lng:-123.1},{l:"Canada",lat:43.65,lng:-79.38},{l:"Canada",lat:45.42,lng:-75.69},{l:"Jeddah, Saudi Arabia",lat:21.39,lng:39.86},{l:"South Africa",lat:-26.2,lng:28.04},{l:"Colombia",lat:4.71,lng:-74.07},{l:"Philippines",lat:14.6,lng:120.98},{l:"Philippines",lat:10.31,lng:123.89},{l:"South Korea",lat:37.57,lng:126.98},{l:"UAE",lat:25.2,lng:55.27},{l:"Iraq",lat:33.34,lng:44.4},{l:"Cairo, Egypt",lat:30.04,lng:31.24},{l:"Pakistan",lat:33.72,lng:73.04},
    {l:"Staten Island, NY",lat:40.58,lng:-74.15},{l:"New Jersey",lat:40.06,lng:-74.41},{l:"Moorestown, NJ",lat:39.97,lng:-74.95},{l:"New Jersey",lat:40.22,lng:-74.76},{l:"New Jersey",lat:40.58,lng:-74.55},{l:"Queens, NY",lat:40.73,lng:-73.79},{l:"Levittown, NY",lat:40.73,lng:-73.51},{l:"Bronx, NY",lat:40.84,lng:-73.86},{l:"South Richmond Hill, NY",lat:40.69,lng:-73.82},{l:"New York, NY",lat:40.71,lng:-74.01},{l:"Springfield, MA",lat:42.1,lng:-72.59},{l:"Holden, MA",lat:42.35,lng:-71.86},{l:"Malden, MA",lat:42.43,lng:-71.07},{l:"Rockland, MA",lat:42.13,lng:-70.91},{l:"Massachusetts",lat:42.27,lng:-71.5},{l:"Massachusetts",lat:42.5,lng:-71.2},{l:"Nashua, NH",lat:42.77,lng:-71.47},{l:"Fairfield, CT",lat:41.14,lng:-73.26},{l:"Downingtown, PA",lat:40.01,lng:-75.7},
    {l:"Maryland",lat:39.05,lng:-76.64},{l:"Waldorf, MD",lat:38.6,lng:-76.86},{l:"Baltimore, MD",lat:39.29,lng:-76.61},{l:"Maryland",lat:39.34,lng:-77.26},{l:"Hampton, VA",lat:37.03,lng:-76.35},{l:"Stafford, VA",lat:38.42,lng:-77.41},{l:"Glen Allen, VA",lat:37.65,lng:-77.5},{l:"Morrisville, NC",lat:35.83,lng:-78.82},{l:"Birmingham, AL",lat:33.52,lng:-86.81},{l:"Little Rock, AR",lat:34.75,lng:-92.29},{l:"Alpharetta, GA",lat:34.08,lng:-84.29},{l:"Cumming, GA",lat:34.21,lng:-84.14},
    {l:"Pembroke Pines, FL",lat:26.01,lng:-80.3},{l:"Palm Bay, FL",lat:28.03,lng:-80.59},{l:"Kissimmee, FL",lat:28.29,lng:-81.41},{l:"Florida",lat:27.77,lng:-81.69},{l:"Florida",lat:26.5,lng:-80.07},
    {l:"Corpus Christi, TX",lat:27.8,lng:-97.4},{l:"San Antonio, TX",lat:29.42,lng:-98.49},{l:"Fort Worth, TX",lat:32.76,lng:-97.33},{l:"Houston, TX",lat:29.76,lng:-95.37},{l:"Houston, TX",lat:29.95,lng:-95.58},
    {l:"Metro Detroit, MI",lat:42.33,lng:-83.05},{l:"Illinois",lat:41.8,lng:-87.82},{l:"Mount Vernon, IN",lat:37.93,lng:-87.89},
    {l:"San Diego, CA",lat:32.72,lng:-117.16},{l:"Pacoima, CA",lat:34.26,lng:-118.41},{l:"Fremont, CA",lat:37.55,lng:-121.99},{l:"San Luis Obispo, CA",lat:35.28,lng:-120.66},{l:"El Sobrante, CA",lat:37.97,lng:-122.29},{l:"California",lat:36.78,lng:-119.42},{l:"California",lat:34.1,lng:-117.55},{l:"California",lat:37.3,lng:-121.8},
    {l:"Beaumont, CA",lat:33.93,lng:-116.98},{l:"Arcadia, CA",lat:34.14,lng:-118.04},{l:"Perth Amboy, NJ",lat:40.51,lng:-74.27},{l:"Philadelphia, PA",lat:39.95,lng:-75.17},{l:"Gainesville, VA",lat:38.73,lng:-77.64},
    {l:"Nigeria",lat:9.08,lng:8.68},{l:"Auckland, New Zealand",lat:-36.87,lng:174.77},{l:"New Zealand",lat:-43.53,lng:172.64},{l:"Dubai, UAE",lat:25.2,lng:55.27}
  ];

  var S = 480, R = 226, cx = S / 2, cy = S / 2, SENS = 0.3;
  var ctx = canvas.getContext('2d');
  var dpr = window.devicePixelRatio || 1;
  canvas.width = S * dpr; canvas.height = S * dpr;
  ctx.scale(dpr, dpr);

  var tip = document.getElementById('gtip');
  var loader = document.getElementById('gloader');
  var proj = d3.geoOrthographic().scale(R).translate([cx, cy]).clipAngle(90).rotate([80, -25]);
  var gpath = d3.geoPath(proj, ctx);
  var grat = d3.geoGraticule()();
  var cgen = d3.geoCircle();
  var feats = null, auto = true, drag = false, lx = 0, ly = 0;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function vis(lng, lat) {
    var r = proj.rotate();
    var l = (lng + r[0]) * Math.PI / 180, p1 = lat * Math.PI / 180, p2 = -r[1] * Math.PI / 180;
    return Math.sin(p1) * Math.sin(p2) + Math.cos(p1) * Math.cos(p2) * Math.cos(l) > 0;
  }
  function render() {
    ctx.clearRect(0, 0, S, S);
    ctx.beginPath(); gpath({type: 'Sphere'}); ctx.fillStyle = '#dcebe0'; ctx.fill();
    ctx.beginPath(); gpath(grat); ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = .5; ctx.stroke();
    if (feats) feats.forEach(function (f) {
      ctx.beginPath(); gpath(f); ctx.fillStyle = '#86b88f'; ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,.6)'; ctx.lineWidth = .5; ctx.stroke();
    });
    vols.forEach(function (v) {
      if (!vis(v.lng, v.lat)) return;
      ctx.beginPath(); gpath(cgen.center([v.lng, v.lat]).radius(1.2)());
      ctx.fillStyle = '#1c3524'; ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,.95)'; ctx.lineWidth = 1; ctx.stroke();
    });
  }
  (function tick() {
    if (auto && !drag && !reduce) { var r = proj.rotate(); proj.rotate([r[0] + .13, r[1]]); }
    render(); requestAnimationFrame(tick);
  })();

  // Pointer position in canvas units (the canvas is scaled by CSS on small screens)
  function pos(clientX, clientY) {
    var rc = canvas.getBoundingClientRect(), k = S / rc.width;
    return {x: (clientX - rc.left) * k, y: (clientY - rc.top) * k, k: k, rc: rc};
  }
  function resume() { drag = false; setTimeout(function () { auto = true; }, 2000); }

  canvas.addEventListener('mousedown', function (e) { drag = true; auto = false; var p = pos(e.clientX, e.clientY); lx = p.x; ly = p.y; });
  window.addEventListener('mousemove', function (e) {
    var p = pos(e.clientX, e.clientY);
    if (drag) {
      var r = proj.rotate();
      proj.rotate([r[0] + (p.x - lx) * SENS, Math.max(-80, Math.min(80, r[1] - (p.y - ly) * SENS))]);
      lx = p.x; ly = p.y; return;
    }
    if (p.x < 0 || p.x > S || p.y < 0 || p.y > S) { tip.style.display = 'none'; return; }
    var near = null, md = Infinity;
    vols.forEach(function (v) {
      if (!vis(v.lng, v.lat)) return;
      var q = proj([v.lng, v.lat]); if (!q) return;
      var d = Math.hypot(q[0] - p.x, q[1] - p.y);
      if (d < 12 && d < md) { md = d; near = v; }
    });
    if (near) {
      tip.style.display = 'block'; tip.textContent = near.l;
      tip.style.left = (p.x / p.k + 10) + 'px'; tip.style.top = Math.max(4, p.y / p.k - 32) + 'px';
    } else tip.style.display = 'none';
  });
  window.addEventListener('mouseup', function () { if (drag) resume(); });
  canvas.addEventListener('mouseleave', function () { tip.style.display = 'none'; });

  // Touch: horizontal swipes spin the globe; vertical swipes still scroll the page
  canvas.addEventListener('touchstart', function (e) { drag = true; auto = false; lx = e.touches[0].clientX; }, {passive: true});
  canvas.addEventListener('touchmove', function (e) {
    var dx = e.touches[0].clientX - lx, r = proj.rotate();
    proj.rotate([r[0] + dx * SENS * 1.5, r[1]]); lx = e.touches[0].clientX;
  }, {passive: true});
  canvas.addEventListener('touchend', resume);

  // Live count of pins, and country chips that fly the globe to that country
  var countEl = document.getElementById('gcount');
  if (countEl) countEl.textContent = vols.length;
  var chips = document.querySelectorAll('[data-geo]'), flyTimer = null;
  function flyTo(lat, lng) {
    auto = false; clearTimeout(flyTimer);
    var from = proj.rotate(), to = [-lng, Math.max(-80, Math.min(80, -lat))];
    var interp = d3.interpolate(from, to), t0 = null, dur = reduce ? 0 : 1100;
    function step(t) {
      if (t0 === null) t0 = t;
      var p = dur ? Math.min(1, (t - t0) / dur) : 1;
      proj.rotate(interp(d3.easeCubicInOut(p)));
      if (p < 1) requestAnimationFrame(step);
      else flyTimer = setTimeout(function () { auto = true; }, 6000);
    }
    requestAnimationFrame(step);
  }
  chips.forEach(function (chip) {
    chip.addEventListener('click', function () {
      var ll = chip.dataset.geo.split(',').map(Number);
      chips.forEach(function (c) { c.setAttribute('aria-pressed', c === chip ? 'true' : 'false'); });
      flyTo(ll[0], ll[1]);
    });
  });

  fetch('https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json')
    .then(function (r) { return r.json(); })
    .then(function (w) { feats = topojson.feature(w, w.objects.countries).features; loader.style.display = 'none'; })
    .catch(function () { loader.textContent = 'Map unavailable'; });
})();
