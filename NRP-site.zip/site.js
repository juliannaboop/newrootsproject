// The New Roots Project — shared behaviour
// mobile nav · scroll reveal · stat counters · scroll progress · back to top · hero slideshow
// typed hero line · gallery lightbox · programs sub-nav · hours estimator · live Discord count
(function () {
  document.documentElement.classList.add('js');
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  /* ---------- Mobile nav ---------- */
  var toggle = $('.nav-toggle'), links = document.getElementById('nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      var open = links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  /* ---------- Scroll progress bar + back-to-top ---------- */
  var header = $('.site-header');
  var bar = document.createElement('div'); bar.className = 'progress';
  if (header) header.appendChild(bar);
  var top = document.createElement('button');
  top.className = 'to-top'; top.type = 'button'; top.setAttribute('aria-label', 'Back to top');
  top.innerHTML = '<i class="ti ti-arrow-up" aria-hidden="true"></i>';
  document.body.appendChild(top);
  top.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' }); });
  /* scroll-linked effects: hero parallax + fade, and the mission statement lighting up word by word */
  var heroEl = $('.hero'), heroBg = heroEl && ($('.hero-slides', heroEl) || $('.hero-bg.on', heroEl)), heroWrap = heroEl && $('.wrap', heroEl), words = [];
  if (!reduce) {
    $all('.mission .big').forEach(function (p) {
      var walk = function (node) {
        Array.prototype.slice.call(node.childNodes).forEach(function (n) {
          if (n.nodeType === 3) {
            var frag = document.createDocumentFragment();
            n.textContent.split(/(\s+)/).forEach(function (part) {
              if (!part) return;
              if (/^\s+$/.test(part)) { frag.appendChild(document.createTextNode(part)); return; }
              var sp = document.createElement('span'); sp.className = 'w'; sp.textContent = part; frag.appendChild(sp);
            });
            node.replaceChild(frag, n);
          } else if (n.nodeType === 1) walk(n);
        });
      };
      walk(p);
      words.push({ el: p, spans: $all('.w', p), lit: 0 });
    });
  }
  var floaters = reduce ? [] : $all('.emblem, .gwrap, .panel.bigstat .num');
  function scrollFx() {
    if (reduce) return;
    var y = window.scrollY, vh = window.innerHeight;
    if (heroEl && y < heroEl.offsetHeight + 100) {
      var k = Math.min(1, y / heroEl.offsetHeight);
      if (heroBg) heroBg.style.transform = 'translate3d(0,' + (y * 0.32).toFixed(1) + 'px,0) scale(' + (1.04 + k * 0.08).toFixed(3) + ')';
      if (heroWrap) { heroWrap.style.transform = 'translate3d(0,' + (y * 0.14).toFixed(1) + 'px,0)'; heroWrap.style.opacity = (1 - k * 1.15).toFixed(3); }
    }
    floaters.forEach(function (el) {                       // these drift a little against the scroll
      var r = el.getBoundingClientRect();
      if (r.bottom < -100 || r.top > vh + 100) return;
      el.style.translate = '0 ' + (((r.top + r.height / 2) - vh / 2) * -0.08).toFixed(1) + 'px';
    });
    words.forEach(function (w) {
      var r = w.el.getBoundingClientRect();
      var prog = Math.max(0, Math.min(1, (vh * 0.9 - r.top) / (vh * 0.45 + r.height * 0.5)));
      var n = Math.round(prog * w.spans.length);
      if (n === w.lit) return;
      w.spans.forEach(function (sp, i) { sp.classList.toggle('lit', i < n); });
      w.lit = n;
    });
  }
  var ticking = false;
  function onScroll() {
    if (ticking) return; ticking = true;
    requestAnimationFrame(function () {
      var max = document.documentElement.scrollHeight - window.innerHeight;
      bar.style.transform = 'scaleX(' + (max > 0 ? Math.min(1, window.scrollY / max) : 0) + ')';
      top.classList.toggle('show', window.scrollY > 700);
      if (header) header.classList.toggle('scrolled', window.scrollY > 12);
      scrollFx();
      ticking = false;
    });
  }
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();

  /* ---------- Photo slideshows (first band of every page): slow cross-fade with a pause button ---------- */
  $all('.hero-slides').forEach(function (slides) {
    var imgs = $all('img', slides), pauseBtn = $('.hero-pause', slides.parentNode), cur = 0, timer = null, hiddenPause = false;
    if (imgs.length < 2) { if (pauseBtn) pauseBtn.style.display = 'none'; return; }
    function next() {
      imgs[cur].classList.remove('on');
      cur = (cur + 1) % imgs.length;
      imgs[cur].loading = 'eager';
      imgs[cur].classList.add('on');
    }
    function label(playing) {
      if (!pauseBtn) return;
      pauseBtn.setAttribute('aria-pressed', playing ? 'false' : 'true');
      pauseBtn.setAttribute('aria-label', playing ? 'Pause photo slideshow' : 'Play photo slideshow');
      pauseBtn.innerHTML = '<i class="ti ti-player-' + (playing ? 'pause' : 'play') + '" aria-hidden="true"></i>';
    }
    function play() { slides.classList.add('playing'); timer = setInterval(next, 6000); label(true); }
    function pause() { slides.classList.remove('playing'); clearInterval(timer); timer = null; label(false); }
    if (pauseBtn) pauseBtn.addEventListener('click', function () { timer ? pause() : play(); });
    document.addEventListener('visibilitychange', function () {       // don't burn through photos in a background tab
      if (document.hidden && timer) { clearInterval(timer); timer = null; hiddenPause = true; }
      else if (!document.hidden && hiddenPause) { hiddenPause = false; timer = setInterval(next, 6000); }
    });
    reduce ? pause() : play();
  });

  /* ---------- Typed hero line ---------- */
  var sub = document.getElementById('hero-sub');
  if (sub && !reduce && sub.dataset.phrases) {
    var phrases = sub.dataset.phrases.split('|'), full = sub.textContent;
    sub.innerHTML = '<span class="sr-only"></span><span aria-hidden="true">' + sub.dataset.lead +
      ' <span class="typed"></span><span class="caret"></span></span>';
    $('.sr-only', sub).textContent = full;
    var typed = $('.typed', sub), pi = 0, ci = 0, deleting = false;
    (function type() {
      var word = phrases[pi], delay;
      if (!deleting) {
        typed.textContent = word.slice(0, ++ci);
        delay = ci === word.length ? 2200 : 45;
        if (ci === word.length) deleting = true;
      } else {
        typed.textContent = word.slice(0, --ci);
        delay = 22;
        if (ci === 0) { deleting = false; pi = (pi + 1) % phrases.length; delay = 350; }
      }
      setTimeout(type, delay);
    })();
  }

  /* ---------- Gallery lightbox ---------- */
  $all('[data-lightbox]').forEach(function (gallery) {
    var pics = $all('img', gallery), idx = 0, lastFocus = null;
    var box = document.createElement('div');
    box.className = 'lightbox'; box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true'); box.setAttribute('aria-label', 'Photo viewer');
    box.innerHTML = '<button class="lb-close" type="button" aria-label="Close"><i class="ti ti-x" aria-hidden="true"></i></button>' +
      '<button class="lb-prev" type="button" aria-label="Previous photo"><i class="ti ti-chevron-left" aria-hidden="true"></i></button>' +
      '<img alt=""><button class="lb-next" type="button" aria-label="Next photo"><i class="ti ti-chevron-right" aria-hidden="true"></i></button>' +
      '<div class="lb-count"></div>';
    document.body.appendChild(box);
    var big = $('img', box), count = $('.lb-count', box);
    function show(i) {
      idx = (i + pics.length) % pics.length;
      big.src = pics[idx].currentSrc || pics[idx].src; big.alt = pics[idx].alt;
      count.textContent = (idx + 1) + ' / ' + pics.length;
    }
    function open(i) { lastFocus = document.activeElement; show(i); box.classList.add('open'); document.body.style.overflow = 'hidden'; $('.lb-close', box).focus(); }
    function close() { box.classList.remove('open'); document.body.style.overflow = ''; if (lastFocus) lastFocus.focus(); }
    pics.forEach(function (img, i) {
      img.tabIndex = 0; img.setAttribute('role', 'button');
      img.addEventListener('click', function () { open(i); });
      img.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(i); } });
    });
    $('.lb-close', box).addEventListener('click', close);
    $('.lb-prev', box).addEventListener('click', function () { show(idx - 1); });
    $('.lb-next', box).addEventListener('click', function () { show(idx + 1); });
    box.addEventListener('click', function (e) { if (e.target === box) close(); });
    document.addEventListener('keydown', function (e) {
      if (!box.classList.contains('open')) return;
      if (e.key === 'Escape') close();
      else if (e.key === 'ArrowLeft') show(idx - 1);
      else if (e.key === 'ArrowRight') show(idx + 1);
      else if (e.key === 'Tab') {            // keep focus inside the viewer
        var btns = $all('button', box), i = btns.indexOf(document.activeElement);
        e.preventDefault(); btns[(i + (e.shiftKey ? -1 : 1) + btns.length) % btns.length].focus();
      }
    });
  });

  /* ---------- Hours estimator (Volunteer page) ---------- */
  var rows = $all('.est-row');
  if (rows.length) {
    var hoursEl = document.getElementById('est-hours'), summary = document.getElementById('est-summary');
    function fmt(n) { return (Math.round(n * 100) / 100).toString(); }
    function update() {
      var total = 0, items = 0;
      rows.forEach(function (r) {
        var n = +$('output', r).textContent;
        total += n * parseFloat(r.dataset.hrs); items += n;
        r.classList.toggle('has', n > 0);
        $('[data-step="-1"]', r).disabled = n === 0;
      });
      hoursEl.textContent = fmt(total);
      summary.textContent = items ? 'Across ' + items + (items === 1 ? ' contribution.' : ' contributions.') : 'Use the + buttons to add contributions.';
    }
    rows.forEach(function (r) {
      $all('button', r).forEach(function (b) {
        b.addEventListener('click', function () {
          var out = $('output', r);
          out.textContent = Math.max(0, Math.min(99, +out.textContent + +b.dataset.step));
          update();
        });
      });
    });
    document.getElementById('est-reset').addEventListener('click', function () {
      rows.forEach(function (r) { $('output', r).textContent = 0; }); update();
    });
    update();
  }

  /* ---------- Live Discord member count ---------- */
  var live = document.getElementById('discord-live');
  if (live && window.fetch) {
    fetch('https://discord.com/api/v10/invites/' + encodeURIComponent(live.dataset.invite) + '?with_counts=true')
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (d) {
        if (!d || !d.approximate_member_count) return;
        var text = d.approximate_member_count.toLocaleString() + ' members in our Discord';
        if (d.approximate_presence_count) text += ' · ' + d.approximate_presence_count.toLocaleString() + ' online now';
        $('span:last-child', live).textContent = text;
        live.hidden = false;
      })
      .catch(function () { /* stays hidden if Discord can't be reached */ });
  }

  /* ---------- Partner bar: a large sage gradient that drifts slowly and is repelled by the cursor ---------- */
  var partners = document.getElementById('partners');
  if (reduce) $all('animate.boil').forEach(function (a) { a.parentNode.removeChild(a); });
  if (partners && !reduce) {
    var layer = $('.blobs', partners);
    var blobs = $all('span', layer).map(function (el, i) {
      return { el: el, hx: 0, hy: 0, ox: 0, oy: 0, ph: i * 2.1, sp: 0.00016 + i * 0.00003, ax: 70 + i * 14, ay: 22 + i * 6 };
    });
    var mouse = null, running = false, pocket = { x: 0, y: 0, a: 0, set: false };
    var measure = function () {
      blobs.forEach(function (b) {
        b.hx = b.el.offsetLeft + b.el.offsetWidth / 2; b.hy = b.el.offsetTop + b.el.offsetHeight / 2;
        b.reach = Math.max(b.el.offsetWidth, b.el.offsetHeight) * 0.75;   // how close the cursor must be
        b.push = Math.min(260, b.reach * 0.45);                           // how far the colour is shoved
      });
    };
    var frame = function (t) {
      if (!running) return;
      blobs.forEach(function (b) {
        var dx = Math.sin(t * b.sp + b.ph) * b.ax, dy = Math.cos(t * b.sp * 0.8 + b.ph) * b.ay;   // ambient drift
        var tx = 0, ty = 0;
        if (mouse) {
          var vx = b.hx + dx - mouse.x, vy = b.hy + dy - mouse.y, d = Math.sqrt(vx * vx + vy * vy) || 1;
          if (d < b.reach) { var f = (1 - d / b.reach) * b.push; tx = vx / d * f; ty = vy / d * f; }
        }
        var k = mouse ? 0.06 : 0.02; b.ox += (tx - b.ox) * k; b.oy += (ty - b.oy) * k;                                 // springy follow
        b.el.style.transform = 'translate3d(' + (dx + b.ox).toFixed(1) + 'px,' + (dy + b.oy).toFixed(1) + 'px,0)';
      });
      // the cleared pocket trails the cursor; it keeps its size and simply fades in and out
      if (mouse) {
        if (!pocket.set) { pocket.x = mouse.x; pocket.y = mouse.y; pocket.set = true; }
        pocket.x += (mouse.x - pocket.x) * 0.14; pocket.y += (mouse.y - pocket.y) * 0.14;
      }
      pocket.a += ((mouse ? 1 : 0) - pocket.a) * (mouse ? 0.06 : 0.02);
      if (pocket.a < 0.004 && !mouse) { pocket.a = 0; pocket.set = false; }
      layer.style.setProperty('--cx', pocket.x.toFixed(1) + 'px');
      layer.style.setProperty('--cy', pocket.y.toFixed(1) + 'px');
      layer.style.setProperty('--a', pocket.a.toFixed(3));
      requestAnimationFrame(frame);
    };
    measure();
    window.addEventListener('resize', measure);
    partners.addEventListener('mousemove', function (e) {
      var r = layer.getBoundingClientRect(); mouse = { x: e.clientX - r.left, y: e.clientY - r.top };
    });
    partners.addEventListener('mouseleave', function () { mouse = null; });
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (en) {          // only animate while the bar is on screen
        var on = en[0].isIntersecting;
        if (on && !running) { running = true; requestAnimationFrame(frame); } else if (!on) running = false;
      }).observe(partners);
    } else { running = true; requestAnimationFrame(frame); }
  }

  /* ---------- Testimonial carousel ----------
     Each card's clipped height is locked, so opening one on hover overlays the page instead of
     pushing the layout around; the carousel eases to a stop while a card is being read. */
  var tmMarquee = document.getElementById('tm-marquee');
  if (tmMarquee && !reduce) {
    var tmItems = $all('.tm-item', tmMarquee), tmTrack = $('.tm-track', tmMarquee), tmW = 0;
    var fitTm = function (force) {
      if (!force && window.innerWidth === tmW) return;      // ignore height-only resizes (mobile address bar)
      tmW = window.innerWidth;
      tmItems.forEach(function (it) {
        var fig = $('.quote', it), bq = $('blockquote', it);
        fig.style.transition = 'none'; bq.style.transition = 'none';
        it.classList.add('measuring'); it.style.height = 'auto';
        bq.style.maxHeight = '6.8em';                       // measure the clipped state even if hovered
        var h = fig.offsetHeight;
        bq.style.setProperty('--full', bq.scrollHeight + 'px');
        bq.style.maxHeight = '';
        it.style.height = h + 'px';
        void fig.offsetHeight; fig.style.transition = ''; bq.style.transition = '';
      });
    };
    fitTm(true);
    window.addEventListener('load', function () { fitTm(true); });
    window.addEventListener('resize', function () { fitTm(false); });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { fitTm(true); });

    // ease the scroll speed down to zero while hovered or focused, and back up afterwards
    var tmAnim = tmTrack.getAnimations ? tmTrack.getAnimations()[0] : null, rate = 1, target = 1, easing = false;
    function ease() {
      rate += (target - rate) * 0.1;
      if (Math.abs(target - rate) < 0.01) rate = target;
      tmAnim.playbackRate = rate;
      if (rate !== target) requestAnimationFrame(ease); else easing = false;
    }
    function setTarget(v) { if (!tmAnim) return; target = v; if (!easing) { easing = true; requestAnimationFrame(ease); } }
    if (!tmAnim) tmMarquee.classList.add('css-pause');
    tmMarquee.addEventListener('mouseenter', function () { setTarget(0); });
    tmMarquee.addEventListener('mouseleave', function () { if (!tmMarquee.contains(document.activeElement)) setTarget(1); });
    tmMarquee.addEventListener('focusin', function () { setTarget(0); });
    tmMarquee.addEventListener('focusout', function () { if (!tmMarquee.matches(':hover')) setTarget(1); });
  }

  /* ---------- Timeline: entries slide in and the centre line fills as the page scrolls ---------- */
  var timeline = document.getElementById('timeline');
  if (timeline && !reduce) {
    var tmlFill = $('.tml-fill', timeline), tmlItems = $all('.tml-item', timeline), tmlTick = false;
    var tmlUpdate = function () {
      tmlTick = false;
      var vh = window.innerHeight, r = timeline.getBoundingClientRect(), mark = vh * 0.62;
      tmlFill.style.transform = 'scaleY(' + Math.max(0, Math.min(1, (mark - r.top) / r.height)).toFixed(4) + ')';
      tmlItems.forEach(function (it) {
        var top = it.getBoundingClientRect().top;
        it.classList.toggle('on', top + 30 < mark);                // dot lights up once the line reaches it
      });
    };
    var tmlQueue = function () { if (!tmlTick) { tmlTick = true; requestAnimationFrame(tmlUpdate); } };
    window.addEventListener('scroll', tmlQueue, { passive: true });
    window.addEventListener('resize', tmlQueue);
    tmlUpdate();
  }

  /* ---------- Reveal, counters, sub-nav highlight ---------- */
  var reveals = $all('.reveal'), counters = $all('[data-count]');
  if (!('IntersectionObserver' in window)) {
    reveals.forEach(function (el) { el.classList.add('in'); });
    return;
  }

  var subLinks = $all('#subnav a');
  if (subLinks.length) {
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        subLinks.forEach(function (a) { a.classList.toggle('active', a.getAttribute('href') === '#' + e.target.id); });
      });
    }, { rootMargin: '-35% 0px -55% 0px' });
    subLinks.forEach(function (a) { var t = $(a.getAttribute('href')); if (t) spy.observe(t); });
  }

  if (reduce) { reveals.forEach(function (el) { el.classList.add('in'); }); return; }

  /* Scroll-linked reveals. Every element's position and opacity is driven by how far it has been
     scrolled into view, so things rise / slide in as you scroll and retreat if you scroll back up.
     A little easing toward the target each frame gives the motion some weight. */
  var scrub = [], scrubRunning = false;
  function scrubAdd(el, ref, o) {
    if (el) scrub.push({ el: el, ref: ref || el, x: o.x || 0, y: o.y || 0, r: o.r || 0, s: o.s || 1, d: o.d || 0, cur: -1, done: false });
  }
  function has(el, c) { return !!el && el.classList && el.classList.contains(c); }
  reveals.forEach(function (el) {
    var par = el.parentNode;
    var idx = par ? Array.prototype.filter.call(par.children, function (c) { return has(c, 'reveal'); }).indexOf(el) : 0;
    if (has(el, 'row')) {                                   // picture and text meet from opposite sides
      var dir = has(el, 'flip') && window.innerWidth > 960 ? -1 : 1;
      scrubAdd(el.firstElementChild, el, { x: -120 * dir });
      scrubAdd(el.lastElementChild, el, { x: 120 * dir, d: 0.06 });
    } else if (has(el, 'stats')) {                          // stats rise one after another
      $all('.stat', el).forEach(function (st, i) { scrubAdd(st, el, { y: 70, d: i * 0.1 }); });
    } else if (has(el, 'sec-head')) scrubAdd(el, null, { x: -80 });
    else if (has(par, 'grid-3') || has(par, 'grid-2')) scrubAdd(el, par, { y: 130, r: 3, d: idx * 0.14 });
    else if (has(par, 'globe-layout') || has(par, 'feature')) scrubAdd(el, par, idx === 0 ? { x: -130, r: has(par, 'globe-layout') ? -8 : 0 } : { x: 130, d: 0.05 });
    else if (has(el, 'logo-marquee') || has(el, 'tm-marquee')) scrubAdd(el, null, { x: 170 });
    else if (el.closest && el.closest('.cta')) scrubAdd(el, null, { y: 80, s: 0.9 });
    else scrubAdd(el, null, { y: 110 });
    if (has(el, 'mission-grid')) scrubAdd($('.emblem', el), el, { x: 110, r: 14, d: 0.1 });
  });
  $all('.tml-item').forEach(function (it, i) {              // timeline cards slide in from their own side
    scrubAdd($('.tml-card', it), it, { x: window.innerWidth <= 820 ? 60 : (i % 2 ? 70 : -70) });
  });
  function docTop(el) { var y = 0; while (el) { y += el.offsetTop; el = el.offsetParent; } return y; }   // layout position, ignoring transforms
  function scrubStep() {
    var y = window.scrollY, vh = window.innerHeight, active = false;
    scrub.forEach(function (it) {
      var t = Math.max(0, Math.min(1, (y + vh * 0.97 - docTop(it.ref)) / (vh * 0.45) - it.d));
      if (it.cur < 0) it.cur = t; else it.cur += (t - it.cur) * 0.16;
      if (Math.abs(t - it.cur) < 0.002) it.cur = t; else active = true;
      var p = it.cur, st = it.el.style;
      if (p >= 1) {
        if (!it.done) { st.opacity = 1; st.transform = ''; st.transition = ''; it.done = true; }
        return;
      }
      var k = (1 - p) * (1 - p);                            // distance still to travel (eases out as it lands)
      it.done = false; st.transition = 'none';
      st.opacity = Math.min(1, p * 1.7).toFixed(3);
      st.transform = 'translate3d(' + (it.x * k).toFixed(1) + 'px,' + (it.y * k).toFixed(1) + 'px,0) rotate(' + (it.r * k).toFixed(2) + 'deg) scale(' + (1 - (1 - it.s) * k).toFixed(3) + ')';
    });
    if (active) requestAnimationFrame(scrubStep); else scrubRunning = false;
  }
  function scrubKick() { if (!scrubRunning) { scrubRunning = true; requestAnimationFrame(scrubStep); } }
  window.addEventListener('scroll', scrubKick, { passive: true });
  window.addEventListener('resize', scrubKick);
  window.addEventListener('load', scrubKick);
  scrubKick();

  // Count-up for stats: <div class="num" data-count="26" data-suffix="K+">26K+</div>
  function countUp(el) {
    var target = parseFloat(el.dataset.count), prefix = el.dataset.prefix || '', suffix = el.dataset.suffix || '';
    var start = null, dur = 1400;
    (function frame(t) {
      if (t === undefined) return requestAnimationFrame(frame);
      if (start === null) start = t;
      var p = Math.min(1, (t - start) / dur);
      el.textContent = prefix + Math.round(target * (1 - Math.pow(1 - p, 3))) + suffix;
      if (p < 1) requestAnimationFrame(frame);
    })();
  }
  var cio = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      countUp(e.target); cio.unobserve(e.target);
    });
  }, { threshold: 0.6 });
  counters.forEach(function (el) { cio.observe(el); });
})();
